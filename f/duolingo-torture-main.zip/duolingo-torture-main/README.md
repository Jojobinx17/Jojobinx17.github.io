# Duolingo Torture - Invasive Duolingo Reminders (v0.2)

_This extension should work on any chromium-based browser (Chrome, Edge, Opera, etc). Chrome and Edge have been confirmed to work as intended. <br><br>
Firefox is not supported at this time._

### To install (chrome):

- Download the extension [here](https://jojobinx.com/download.html#duolingo-torture) and extract (unzip) it.
- Go to 'chrome://extensions' on Google Chrome.
- In the top right, turn on 'Developer mode'. You can turn this off once you load the extension.
- Now, on the top left, select 'Load unpacked'. Select the folder on your computer containing the code from this repository.
- Follow the instructions on-screen and enjoy!

### To install on other platforms:
- Follow the first step.
- Figure it out, I guess (the steps should be similar to Chrome's). You got this!

_Note: This project is still in active development/testing. Please report any issues to this repositories's issues tab, or contact help.jojobinx17@gmail.com. Thank you!_
