# Duolingo Torture - Invasive Duolingo Reminders (v0.2)

_This extension should work on any chromium-based browser (Chrome, Edge, Opera, etc). Chrome and Edge have been confirmed to work as intended._

To install (chrome):

- Download repository and move it (uncompressed) into an empty folder on your computer. Name the folder whatever you want.
- Go to 'chrome://extensions' on Google Chrome.
- In the top right, turn on 'Developer mode'. You can turn this off once you load the extension.
- Now, on the top left, select 'Load unpacked'. Select the folder on your computer containing the code from this repository.
- Follow the instructions on-screen and enjoy!

_Note: This project is still in active development/testing. Please report any issues to this repositories's issues tab, or contact help.jojobinx17@gmail.com. Thank you!_
